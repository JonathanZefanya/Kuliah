# latihan_todo_app_flutter
 
## How To Run
```
flutter pub get (don't forget to connect with emulator)
flutter run
```