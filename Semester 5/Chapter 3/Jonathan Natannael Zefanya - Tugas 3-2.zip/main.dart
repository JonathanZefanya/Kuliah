import 'package:flutter/material.dart';

// Run App
void main() {
  runApp(const RecipeApp());
}

// Class RecipeApp adalah class utama yang merupakan turunan dari StatelessWidget 
class RecipeApp extends StatelessWidget {
  // Constructor untuk membuat RecipeApp dengan key yang unik (opsional)
  const RecipeApp({super.key});

  // Override method build untuk membuat widget
  @override
  Widget build(BuildContext context) {
    // MaterialApp adalah widget yang memuat semua widget yang dibutuhkan oleh aplikasi
    return MaterialApp(
      // Theme adalah tema yang digunakan oleh aplikasi
      theme: ThemeData(primarySwatch: Colors.red),
      home: const RecipeForm(),
    );
  }
}

// Class RecipeForm adalah class yang digunakan untuk membuat form resep
class RecipeForm extends StatelessWidget {
  const RecipeForm({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // AppBar adalah bar yang berisi judul dan tombol aksi
      appBar: AppBar(
        title: const Text('NEW RECIPE'),
        centerTitle: true,
        actions: [
          TextButton(
            onPressed: () {},
            child: const Text(
              'Close',
              style: TextStyle(color: Color.fromARGB(255, 255, 0, 0)), 
            ),
          ),
        ],
      ),

      // Body adalah bagian utama dari aplikasi
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Container adalah widget yang digunakan untuk mengatur layout dari kotak merah
            Container(
              padding: const EdgeInsets.all(16.9),
              color: Colors.redAccent,
              child: const Text(
                'Kereen Banget!!! Sekarang kamu dapat menambahkan resep baru di aplikasi ini. Yuk tambahkan resep baru kamu sekarang juga!',
                style: TextStyle(color: Colors.white),
              ),
            ),

            // Judul form
            // SizedBox adalah widget yang digunakan untuk membuat spasi
            const SizedBox(height: 20),
            // TextField adalah widget yang digunakan untuk membuat input field
            const TextField(
              decoration: InputDecoration( // Decoration adalah properti yang digunakan untuk mengatur tampilan input field
                labelText: 'Masukan Judul Resep Kamu', // Label text yang muncul di atas input field
                hintText: 'Masukkan Nama Menu', // Hint text yang muncul ketika input field kosong dan sedikit transparan
              ),
            ),

            // Waktu Form
            const SizedBox(height: 10),
            const TextField(
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Estimasi Waktu Memasak (menit)',
                hintText: 'Masukkan Waktu Pembuatan',
              ),
            ),

            // Deskripsi Form
            const SizedBox(height: 10),
            const TextField(
              decoration: InputDecoration(
                labelText: 'Deskripsi',
                hintText: 'Masukkan Deskripsi',
              ),
            ),

            // Resep Form
            const SizedBox(height: 10),
            const TextField(
              maxLines: 5,
              decoration: InputDecoration(
                labelText: 'Resep, bahan dan langkah',
                hintText: 'Masukkan Resep dan Cara Pembuatan',
              ),
            ),
            const Spacer(),
            // ElevatedButton adalah widget yang digunakan untuk membuat tombol
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 50),
                backgroundColor: Colors.red,
              ),
              child: const Text(
                'Add Menu',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}