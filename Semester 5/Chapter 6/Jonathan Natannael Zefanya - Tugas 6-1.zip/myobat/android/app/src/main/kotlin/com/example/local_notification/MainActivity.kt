package com.example.myobat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
